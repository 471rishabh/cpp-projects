<h1 align="center">Welcome to Super Market Management 👋</h1>
<p>
  <a href="https://github.com/jayskhatri/Super-Market-Management#readme">
    <img alt="Documentation" src="https://img.shields.io/badge/documentation-yes-brightgreen.svg" target="_blank" />
  </a>
  <a href="https://github.com/kefranabg/readme-md-generator/graphs/commit-activity">
    <img alt="Maintenance" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg" target="_blank" />
  </a>
  <a href="https://github.com/jayskhatri/Super-Market-Management/blob/master/LICENSE">
    <img alt="License: MIT" src="https://img.shields.io/badge/License-MIT-yellow.svg" target="_blank" />
  </a>
</p>

> It&#39;s my 2nd sem project on super market management which is in c++. Simple billing and market management project in c++. It has admin panel where admin can manage stock of items and customer can buy the items. Bill is auto generated. Just clone the Repository and run the main cpp file with gcc

### 🏠 [Homepage](https://github.com/jayskhatri/Super-Market-Management)

## Prerequisites

- Code is optimized to be compile with gcc only.

## Author

👤 **Jay Khatri**

* Twitter: [@jayskhatri](https://twitter.com/jayskhatri)
* Github: [@jayskhatri](https://github.com/jayskhatri)

👤 **Isha Khimsurya**

* Github: [@ishakhimsurya](https://github.com/ishakhimsurya)

👤 **Naimish Ghevariya**

* Github: [@NaimishGhevariya](https://github.com/NaimishGhevariya)

## 🤝 Contributing

Contributions, issues and feature requests are welcome !<br />Feel free to check [issues page](https://github.com/jayskhatri/Super-Market-Management/issues).

## Show your support

Give a ⭐️ if this project helped you !

## 📝 License

Copyright © 2019 [Jay Khatri](https://github.com/jayskhatri).<br />
This project is [MIT](https://github.com/jayskhatri/Super-Market-Management/blob/master/LICENSE) licensed.

***
_This README was generated with ❤️ by [readme-md-generator](https://github.com/jayskhatri/readme-md-generator)_
